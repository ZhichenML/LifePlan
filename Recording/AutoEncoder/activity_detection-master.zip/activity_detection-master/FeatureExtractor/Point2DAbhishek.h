#ifndef POINT2DABHISHEK_H
#define POINT2DABHISHEK_H

class Point2DAbhishek
{
public:
  int x;
  int y;
  Point2DAbhishek(int x_,int y_)
  {
    x=x_;
    y=y_;
  }
  Point2DAbhishek()
  {
  }
};

#endif
